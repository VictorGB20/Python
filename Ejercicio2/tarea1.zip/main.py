import sys,tarea1 as t



def main():
    '''
        Dado el numero introducido por el usuario, mostrara la tabla de multiplicar del numero
    '''
    t.numero = 0
    t.pedir_numero()
    



#llamar función principal
if __name__ == "__main__":
    main()

